<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68729e814a3e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Section; class SettingSection extends Section { public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
