<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843f402d1852             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Section; class SettingSection extends Section { public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
