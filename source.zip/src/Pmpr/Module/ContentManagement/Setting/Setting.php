<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68729e814a3e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->igiywquyccyiaucw(Constants::qoquaeuooeycomks, $this->mwikyscisascoeea())->gswweykyogmsyawy(__('Content Management Setting', PR__MDL__CONTENT_MANAGEMENT))->igiywquyccyiaucw(Constants::qsegwakiwaiyimyy, __('Setting', PR__MDL__CONTENT_MANAGEMENT)); } }
