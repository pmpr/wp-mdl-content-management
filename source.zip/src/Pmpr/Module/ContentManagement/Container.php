<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68729e814a3e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
