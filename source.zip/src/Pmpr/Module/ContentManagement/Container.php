<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             684453f67f65f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
