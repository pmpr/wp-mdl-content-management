<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68729e814a3e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement\EditorialComment\Model; class Attachment { }
