<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6844600a48a68             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement\EditorialComment\Model; class Attachment { }
