<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             684453f67f65f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement\EditorialComment\Model; class Attachment { }
