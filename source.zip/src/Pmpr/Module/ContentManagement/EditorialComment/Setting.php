<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843f402d1852             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement\EditorialComment; use Pmpr\Module\ContentManagement\Setting\SettingSegment; class Setting extends SettingSegment { }
