<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843f33324655             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement\EditorialComment; use Pmpr\Module\ContentManagement\Setting\SettingSegment; class Setting extends SettingSegment { }
