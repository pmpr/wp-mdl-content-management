<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68729e814a3e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement\EditorialComment; use Pmpr\Module\ContentManagement\Setting\SettingSegment; class Setting extends SettingSegment { }
