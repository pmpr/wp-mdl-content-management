<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843efc65ced4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ContentManagement\EditorialComment; use Pmpr\Module\ContentManagement\Container; use Pmpr\Module\ContentManagement\EditorialComment\Model\Comment; use Pmpr\Module\ContentManagement\EditorialComment\Model\Quote; class EditorialComment extends Container { public function mameiwsayuyquoeq() { Quote::symcgieuakksimmu(); Comment::symcgieuakksimmu(); MetaBox::symcgieuakksimmu(); if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::PREFIX)) { Ajax::symcgieuakksimmu(); } } }
